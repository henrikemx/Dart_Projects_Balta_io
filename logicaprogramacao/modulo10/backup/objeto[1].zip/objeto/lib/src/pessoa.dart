

class Pessoa{

  String nome = 'Jacob';
  int idade = 27;
  String sexo = 'M';

}