
import 'dart:io';
import 'src/pessoa.dart';

void main(List<String> arguments) {
  
  var pessoa = Pessoa();

  stdout.writeln('Nome: ' + pessoa.nome);
  stdout.writeln('Idade: ' + pessoa.idade.toString());
  if (pessoa.sexo == 'M'){
    print('Sexo: Masculino');
  } else {
    print('Sexo: Feminino');
  }
}
