class Pessoa {

  String nome;
  int idade;
  double altura;
  double peso;

  // metodo para calcular o IMC
  // metodo para identificar a idade

  double imc(){
    double imc = peso / (altura * altura);
    return imc;
  }

  bool maiorIdade(){
    if (idade >= 18){
      return true;
    } else {
      return false;
    }
  }

}