import 'humano.dart';

class Pessoa extends humano {

  String nome;
  int idade;
  String sexo;
  
  // exemplo de um método construtor..
  // no exemplo abaixo, os argumentos foram inseridos entre
  // parentesis permite ao programador associar a variável ao seu tipo
  Pessoa ({this.nome, this.idade, this.sexo});

}