class humano {
  
  int peso;
  double altura;

}