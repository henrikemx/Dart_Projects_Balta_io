import 'dart:io';
import 'src/pessoa.dart';

void main(List<String> arguments) {
  
  Pessoa pessoa = Pessoa(nome: 'Jacobd', idade: 27, sexo: 'M', );

  // exibe o conteúdo da lista
  stdout.writeln('Nome: ' + pessoa.nome);
  stdout.writeln('Idade: ' + pessoa.idade.toString());
  stdout.writeln('Peso: ' + pessoa.peso.toString());
  stdout.writeln('Altura: ' + pessoa.altura.toString());
  if (pessoa.sexo == 'M'){
    print('Sexo: Masculino');
  } else if (pessoa.sexo == 'F') {
    print('Sexo: Feminino');
  } else {
    print('Gênero Não Natural !!!');
  }
}
