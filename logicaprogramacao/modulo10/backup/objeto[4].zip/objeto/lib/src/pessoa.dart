class Pessoa{

  String nome;
  int idade;
  String sexo;

  // este NÃO é um método construtor... é um método de inicialização
  // inicializar(String nome, int idade, String sexo){
  // exemplo de um método construtor..
  // no exemplo abaixo, os argumentos foram inseridos entre
  // parentesis permite ao programador associar a variável ao seu tipo
  Pessoa ({String nome, int idade, String sexo}) {
    this.nome = nome;
    this.idade = idade;
    this.sexo = sexo;
  }

}