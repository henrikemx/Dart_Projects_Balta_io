class Animal {

  String barulho;
  Animal({this.barulho});

}