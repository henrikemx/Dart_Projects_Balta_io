import 'src/gato.dart';

void main(List<String> arguments) {

  Gato gato = Gato(nome: "George", barulho: "Miau");
  print("Gato ${gato.nome} faz ${gato.barulho}");

}
