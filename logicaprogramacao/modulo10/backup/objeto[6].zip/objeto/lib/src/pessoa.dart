class Pessoa{

  String nome;
  int idade;
  String sexo;

  // String _nomelocal = 'Esta é uma variável local...';

  String otherNome = 'Moura';

  // exemplo de um método construtor..
  // no exemplo abaixo, os argumentos foram inseridos entre
  // parentesis permite ao programador associar a variável ao seu tipo
  Pessoa ({this.nome, this.idade, this.sexo});

}