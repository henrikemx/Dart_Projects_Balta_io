import 'dart:io';
import 'src/pessoa.dart';

void main(List<String> arguments) {
  
  Pessoa pessoa = Pessoa('Jean', 40, 'G');

  // exibe o conteúdo da lista
  stdout.writeln('Nome: ' + pessoa.nome);
  stdout.writeln('Idade: ' + pessoa.idade.toString());
  if (pessoa.sexo == 'M'){
    print('Sexo: Masculino');
  } else if (pessoa.sexo == 'F') {
    print('Sexo: Feminino');
  } else {
    print('Gênero Não Natural !!!');
  }
}
