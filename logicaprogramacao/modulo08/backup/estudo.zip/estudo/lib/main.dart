/* a linha abaixo, por enquanto, não será utilizada
 * import 'package:estudo/estudo.dart' as estudo;
 * Nesse módulo será tratado sobre "lista de Strings ou argumentos";
 * 
*/


import 'estudo.dart';

void main(List<String> arguments) {
  // e nem o print abaixo...
  // print('Hello world: ${estudo.calculate()}!');
  print(calculate());
  
}
