/* a linha abaixo, por enquanto, não será utilizada
 * import 'package:estudo/estudo.dart' as estudo;
 * Nesse módulo será tratado sobre "lista de Strings ou argumentos";
 * 
*/


void main(List<String> arguments) {

  print(arguments);
    
}
